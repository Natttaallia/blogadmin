<nav class="blog-pagination">

	<?php if($paginator->hasMorePages()): ?>
		<a class="btn btn-outline-primary" 
		href="<?php echo e($paginator->nextPageUrl()); ?>"
	>Older</a>
	<?php else: ?>
		<a class="btn btn-outline-primary disabled" href="#">Older</a>
	<?php endif; ?>
		
	<?php if($paginator->onFirstPage()): ?>
		<a class="btn btn-outline-secondary disabled" href="#">Newer</a>
	<?php else: ?>
		<a class="btn btn-outline-secondary" 
		href="<?php echo e($paginator->previousPageUrl()); ?>"
	>Newer</a>
	<?php endif; ?>
	
</nav>