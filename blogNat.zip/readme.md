# Для развертки проекта

1. `composer install`
2. `npm install`
3. `npm run watch` | `npm run dev` | `npm run prod`