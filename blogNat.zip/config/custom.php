<?php

return [
	'paginate_quote' => 5
];